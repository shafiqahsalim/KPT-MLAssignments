# Face Detection > 2022-08-01 3:08pm
https://universe.roboflow.com/object-detection/face-detection-yvzba

Provided by Roboflow
License: CC BY 4.0

